function HRDashboard()
{
    return(
        <h1>
            Welcome to HR dashboard
        </h1>
    )
}

export default HRDashboard;